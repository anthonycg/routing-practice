import React from "react";
import { BrowserRouter } from "react-router-dom";

const Home = (props) => {
    return (
        <div>
            <p>Welcome</p>
        </div>
    )
}

export default Home;